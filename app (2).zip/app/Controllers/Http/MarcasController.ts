// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

import Marca from "App/Models/Marca";

export default class MarcasController {

   async index() {
        return await Marca.query().paginate(1,2)
    }

    store({request}) {
        const dados = request.only(['nome'])

        return Marca.create(dados)
    }

    async show({request}) {
        const id = request.param('id')
        return await Marca.findOrFail(id)
    }


}
